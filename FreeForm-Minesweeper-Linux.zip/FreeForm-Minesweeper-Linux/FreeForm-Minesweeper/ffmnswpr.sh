#!/bin/bash
cd /usr/local/share/FreeForm-Minesweeper/ && /usr/local/share/FreeForm-Minesweeper/FreeForm-Minesweeper.sh
